<?php
return [
	'routes' => [
		['name' => 'mfazones#get', 'url' => '/get', 'verb' => 'GET'],
		['name' => 'mfazones#access', 'url' => '/access', 'verb' => 'GET'],
		['name' => 'mfazones#set', 'url' => '/set', 'verb' => 'POST'],
	]
];
